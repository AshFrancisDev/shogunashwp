<script type="text/javascript">
    <?php echo esc_js( $script ); ?>
</script>